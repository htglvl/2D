
============================================================

Sample Model
Hiyori Momose - FREE

============================================================

　It is a standard model created with Cubism3.

　You can learn the structure of deformers and the mechanism of parameters.
　The new function「Glue」is used on both parts of shoulders.


------------------------------
License Agreement
------------------------------

　You need to agree "Free Material License Agreement" to use this sample model.
　General Users and Small-Scale Enterprise Users can use the model for
　commercial purposes by accepting the "Free Material License Agreement".
　Parties other than General User or Small-Scale Enterprise User are
　allowed to use the model for Internal or Supervision Purpose.
　Please refer to this agreement for more details.

【Free Material License Agreement】
　https://www.live2d.jp/en/terms/live2d-free-material-license-agreement/

【Terms of Use for Live2D Cubism Sample Models】
　https://docs.google.com/document/d/e/2PACX-1vTz65pfSReDw6NTheqxQzfqSj_tgQn1D35PHCQE3EgLKiR80-TFtjvk6WPRL-0g-TMfjJMEgf-7sfvp/pub


------------------------------
Created By
------------------------------

　Illustration：Kani Biimu
　Modeling：Live2D


------------------------------
Sample Data Composition
------------------------------

　Model Data(cmo3) Note:Including physics settings
　Basic motion(can3)
　Set of built-in files (runtime folder)
　・Model data (moc3)
　・Motion data (motion3.json)
　・Model setting file (model3.json)
　・Physical calculation setting file (physics3.json)
　・Pose setting file (pose3.json)
　・Display auxiliary file (cdi3.json)


------------------------------
Release Note
------------------------------

【cmo3】

　hiyori_free_t08
　2021/6/10　Released


【can3】

　hiyori_free_t03
　2021/6/10　Released